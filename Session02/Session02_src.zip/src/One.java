public class One {
    public static void main(String[] args) {
        int[] numbers = new int[5];
        int[] numbers2 = {10 ,20 ,30, 40, 50};
        numbers[0] = 10;
        numbers[1] = 20;

        double[] numbers3 = new double[10];
        numbers3[0] = 2.5;

        int[][] matrix = new int[4][4];
        matrix[0][0] = 1;
        matrix[2][1] = 10;

        int[][] matrix2 = {{1,2,3} , {4,5,6}};
    }
}
