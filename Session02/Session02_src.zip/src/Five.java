import java.util.Scanner;

public class Five {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter x:");
        int x = input.nextInt();
        System.out.print("Enter y:");
        int y = input.nextInt();
        System.out.println("x = " + x + " , y = " + y);
//        String line = input.nextLine();
//        System.out.println("User Entered : " + line);
    }
}
