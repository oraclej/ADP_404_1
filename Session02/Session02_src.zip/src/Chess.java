public class Chess {
    public static void main(String[] args) {
        ChessPiece horse = new ChessPiece();
        horse.name = "Horse1";
        horse.color = "WHITE";
        horse.x = 1;
        horse.y = 0;
        horse.isCaptured = true;
    }
}
