public class Adder {
    public void aMethod(){
        add(7,8);
    }
    public static void main(String[] args) {
        int r = add(2,3);
    }

    public static int add(int a, int b){
        return a+b;
    }
}
