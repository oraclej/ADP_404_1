public class Main {
    public static void main(String[] args) {
//        Student ali = new Student();
//        Student reza = new Student();
        System.out.println(Student.CONDITIONAL_GPA);
        Student.printConditionalGpa();

//        System.out.println(ali.getName());
    }
}
